/** Automatically generated file. DO NOT MODIFY */
package org.chromium.webapk.a2ca14b354dee4457_v2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}